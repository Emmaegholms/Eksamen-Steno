# Eksamen-Steno

